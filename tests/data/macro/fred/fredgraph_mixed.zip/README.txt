----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-22 12:53 pm CDT
----------------------------------------------------------------

------------  ----------------------------------------------------------------------  ------------------------
DGS10         Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-10-21
              Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
T10Y2Y        10-Year Treasury Constant Maturity Minus 2-Year Treasury Constant       Data Updated: 2026-10-21
              Maturity, Percent, Daily, Not Seasonally Adjusted
BAMLH0A0HYM2  ICE BofA US High Yield Index Option-Adjusted Spread, Percent, Daily,    Data Updated: 2026-10-22
              Not Seasonally Adjusted
CPILFESL      Consumer Price Index for All Urban Consumers: All Items Less Food and   Data Updated: 2026-10-14
              Energy in U.S. City Average, Index 1982-1984=100, Monthly, Seasonally
              Adjusted
PAYEMS        All Employees, Total Nonfarm, Thousands of Persons, Monthly,            Data Updated: 2026-10-02
              Seasonally Adjusted
------------  ----------------------------------------------------------------------  ------------------------

